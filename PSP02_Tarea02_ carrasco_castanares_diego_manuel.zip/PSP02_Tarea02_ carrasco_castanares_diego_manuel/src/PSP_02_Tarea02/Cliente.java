/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PSP_02_Tarea02;

/**
 *
 * @author diego
 */
public class Cliente extends Thread {

    private int idCliente;
    private FilaUnica filaUnica;

    /**
     * Creamos el constructor
     *
     * @param idCliente
     * @param filaUnica
     */
    public Cliente(int idCliente, FilaUnica filaUnica) {
        this.idCliente = idCliente;
        this.filaUnica = filaUnica;

    }

    /**
     * Creamos el método run en el cual llamado al método nuevoCliente.
     */
    @Override
    public void run() {
        filaUnica.nuevoCliente(idCliente);
    }
}
