/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PSP_02_Tarea02;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author diego
 */
public class Principal {
    
    // Creamos el método main
    public static void main(String[] args) {
        
        int cajaRandom = (int)(Math.random() * 4) + 2; // Generamos un número de cajas aleatorio
        int clienteRandom = (int)(Math.random() * 10) + 5; // Generamos un número de clientes aleatorio
        FilaUnica filaUnica = new FilaUnica(); // Creamos la FilaUnica
        
        System.out.println(clienteRandom + " clientes para " + cajaRandom + " cajas."
                + " Empezamos a trabajar.");
        
        Cliente[] cli = new Cliente[clienteRandom]; // Creamos un array de cliente con los clientes generados
        
        // Insertamos cada cliente en el array e inciamos el hilo de cada cliente
        for (int i = 0; i < clienteRandom; i++){
            cli[i] = new Cliente(i + 1, filaUnica);
            cli[i].start();
            System.out.println("El cliente " + (i + 1) + " llega a la cola");
        } 
        
        Caja[] caj = new Caja[cajaRandom]; // Creamos un array de cajas con las cajas generadas
        
        // Insertamos cada caja en el array e iniciamos el hilo de cada caja
        for (int i = 0; i < cajaRandom; i++){
            caj[i] = new Caja(i + 1, filaUnica);
            caj[i].start();
        }
        
        // Mediante este for y el join esperamos a que se terminen todas las cajas
        for (int i = 0; i < cajaRandom; i++){
            try {
                caj[i].join();
            } catch (InterruptedException ex) {
                Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        // Mediante este for y el join esperamos a que se terminen todos los clientes
        for (int i = 0; i < clienteRandom; i++){
            try {
                cli[i].join();
            } catch (InterruptedException ex) {
                Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        System.out.println("Trabajo terminado, se cierran todas las cajas.");
    }
    
}
