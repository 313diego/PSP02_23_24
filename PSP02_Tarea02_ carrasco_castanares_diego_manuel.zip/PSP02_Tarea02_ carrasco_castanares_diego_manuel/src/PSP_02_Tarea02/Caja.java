/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PSP_02_Tarea02;

import static java.lang.Thread.sleep;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author diego
 */
public class Caja extends Thread {

    private int idCaja;
    private FilaUnica filaUnica;

    /**
     * Creamos el constructor.
     *
     * @param idCaja
     * @param filaUnica
     */
    public Caja(int idCaja, FilaUnica filaUnica) {
        this.idCaja = idCaja;
        this.filaUnica = filaUnica;
    }

    /**
     * Creamos el método run en el cual le daremos un tiempo aleatorio a cada
     * cliente, llamaremos al método terminarCliente, mostramos por pantalla
     * cuando esta libre, cuando esta atendiendo y cuando esta preparada para
     * atender la caja en cuestión, dormiremos al hilo el tiempo que este
     * atendiendo, aumentaremos el contador numClientes para cada cliente. Por
     * último mostraremos por pantalla cuando se termina cada hilo y cuantos
     * clientes ha atendido el hilo en cuestión
     */
    @Override
    public void run() {
        int tiempoCliente;
        int idCliente;
        int numClientes = 0;
        while (filaUnica.isClientesPendientes()) { // Si quedan clientes pendientes...

            try {
                tiempoCliente = (int) (Math.random() * 80 + 10); // Generamos un tiempo aleatorio
                idCliente = filaUnica.terminarCliente(tiempoCliente); // Llamamos al método terminarCliente
                System.out.println("La caja " + idCaja + " preparada para atender al cliente " + idCliente);
                System.out.println("La caja " + idCaja + " esta atendiendo al cliente " + idCliente);
                sleep(tiempoCliente); // Dormimos el hilo el tiempo aleatorio generado antes
                numClientes++; // Aumentamos en uno el contador de los clietnes
                System.out.println("La caja " + idCaja + " esta libre.");
            } catch (InterruptedException ex) {
                Logger.getLogger(Caja.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        System.out.println("La caja " + (idCaja) + " ha terminado su trabajo. Ha atendido a " + numClientes + " clientes.");
    }
}
