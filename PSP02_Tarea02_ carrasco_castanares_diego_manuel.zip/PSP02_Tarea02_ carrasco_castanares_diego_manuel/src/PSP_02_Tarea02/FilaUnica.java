/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PSP_02_Tarea02;

import java.util.PriorityQueue;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author diego
 */
public class FilaUnica extends Thread {
    
    private Semaphore semaforo;
    private PriorityQueue<Integer> listaClientes;

    /**
     * Creamos el constructor
     */
    public FilaUnica() {
        
        /**
         * Inicializamos el semaforo a 1
         */        
        semaforo = new Semaphore(1);
        listaClientes = new PriorityQueue<Integer>();
    }

    /**
     * Creamos el método nuevoCliente para pedir acceso al semaforo y añadir los
     * cliente a la listaClientes
     */
    public void nuevoCliente(Integer idCliente) {
        try {

            semaforo.acquire(); // Pedimos acceso al semaforo
            listaClientes.add(idCliente); // Añade a la lista cliente un nuevo cliente
            semaforo.release(); // Libera el semaforo

        } catch (InterruptedException ex) {
            Logger.getLogger(FilaUnica.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Creamos el método terminarCliente para pedir acceso al semaforo, extraer
     * de la listaClientes el primer cliente que este en ella y volver a liberar
     * el semaforo. Nos retornara el objeto cliente.
     *
     * @param tiempoCliente
     * @return
     */
    public int terminarCliente(int tiempoCliente) {
        int cliente = 0;
        
        if (isClientesPendientes()) { // Si quedan clientes pendientes...

            try {
                semaforo.acquire(); // Pedimos acceso al semaforo
                cliente = listaClientes.poll(); // Extraemos el primer cliente de la lista
                semaforo.release(); // Liberamos el semaforo

            } catch (InterruptedException ex) {
                Logger.getLogger(FilaUnica.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return cliente; // Retornamos el objeto cliente

    }

    /**
     * Creamos el metodo isClientesPendientes para saber si quedan objetos del
     * tipo cliente en la listaClientes.
     *
     * @return
     */
    public boolean isClientesPendientes() {
        return listaClientes.size() > 0;
    }
}
